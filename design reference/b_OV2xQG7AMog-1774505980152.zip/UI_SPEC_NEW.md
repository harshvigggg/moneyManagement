# SmartSpend - Premium Green Fintech UI Specification

## Design Philosophy
A premium, dark-mode-first financial application with a sophisticated green color scheme inspired by modern fintech design. The aesthetic combines deep forest greens with vibrant lime accents, subtle grain textures, and glowing effects to create an immersive, trustworthy financial experience.

---

## Design System

### Primary Color Palette (5 Colors Only)

| Token | Hex | Usage |
|-------|-----|-------|
| **Deep Forest** | `#06231D` | Primary background, darkest elements |
| **Forest Green** | `#0C342C` | Card backgrounds, secondary surfaces |
| **Emerald** | `#076653` | Borders, dividers, secondary accents |
| **Lime Accent** | `#E3EF26` | Primary CTAs, highlights, active states, branding |
| **Cream White** | `#F5F5F0` | Primary text, headings |

### Extended Palette (Semantic Colors)

```
--background-primary: #06231D      /* Deepest green - main bg */
--background-secondary: #0C342C   /* Forest green - cards */
--background-tertiary: #0A2B24    /* Mid-tone for hover states */
--accent-primary: #E3EF26         /* Lime - buttons, highlights */
--accent-primary-hover: #D4E020   /* Darker lime on hover */
--accent-glow: rgba(227, 239, 38, 0.15) /* Lime glow effect */
--text-primary: #F5F5F0           /* Cream white */
--text-secondary: #9CA3AF         /* Muted gray */
--text-muted: #6B7280             /* Subtle gray */
--border-primary: #076653         /* Emerald borders */
--border-subtle: rgba(7, 102, 83, 0.5) /* Transparent border */
--success: #22C55E                /* Income green */
--danger: #EF4444                 /* Expense red */
--warning: #F59E0B                /* Warning amber */
```

### Gradient Definitions

```css
/* Hero gradient - main background */
--gradient-hero: linear-gradient(135deg, #076653 0%, #0C342C 50%, #06231D 100%);

/* Card gradient - subtle depth */
--gradient-card: linear-gradient(180deg, #0C342C 0%, #0A2B24 100%);

/* Accent gradient - for premium elements */
--gradient-accent: linear-gradient(135deg, #E3EF26 0%, #A3B818 100%);

/* Glow effect - for highlighted elements */
--gradient-glow: radial-gradient(ellipse at center, rgba(227, 239, 38, 0.2) 0%, transparent 70%);
```

### Typography

**Font Stack:**
- Primary: `'Inter', 'SF Pro Display', system-ui, sans-serif`
- Mono: `'JetBrains Mono', 'SF Mono', monospace` (for numbers/amounts)

**Scale:**
| Element | Size | Weight | Line Height |
|---------|------|--------|-------------|
| Hero H1 | 48px / 3rem | 700 | 1.1 |
| Page H1 | 32px / 2rem | 700 | 1.2 |
| Section H2 | 24px / 1.5rem | 600 | 1.3 |
| Card Title | 18px / 1.125rem | 600 | 1.4 |
| Body | 16px / 1rem | 400 | 1.5 |
| Small/Meta | 14px / 0.875rem | 400 | 1.4 |
| Caption | 12px / 0.75rem | 500 | 1.4 |

### Border & Shadow System

```css
/* Border radius */
--radius-sm: 8px;
--radius-md: 12px;
--radius-lg: 16px;
--radius-xl: 24px;
--radius-full: 9999px;

/* Shadows */
--shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.3);
--shadow-md: 0 4px 16px rgba(0, 0, 0, 0.4);
--shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.5);
--shadow-glow: 0 0 40px rgba(227, 239, 38, 0.15);
--shadow-glow-lg: 0 0 80px rgba(227, 239, 38, 0.2);

/* Borders */
--border-default: 1px solid rgba(7, 102, 83, 0.5);
--border-accent: 1px solid #E3EF26;
```

### Special Effects

**Grain Texture Overlay:**
```css
.grain-overlay::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%' height='100%' filter='url(%23noise)'/%3E%3C/svg%3E");
  opacity: 0.03;
  pointer-events: none;
}
```

**Glow Effects:**
```css
.glow-lime {
  box-shadow: 0 0 40px rgba(227, 239, 38, 0.15);
}

.glow-text {
  text-shadow: 0 0 20px rgba(227, 239, 38, 0.3);
}
```

---

## Page-by-Page UI Specification

---

### PAGE 1: Landing Page
**Route:** `/`
**Access:** Public

**Full Page Layout:**
- Full viewport height sections
- Deep forest green (#06231D) base background
- Subtle grain texture overlay on entire page

---

#### Section 1: Hero
**Background:** Gradient from #076653 → #0C342C → #06231D with subtle grain

**Navigation Bar (fixed, top):**
```
Height: 72px
Background: transparent (becomes #06231D/90 + backdrop-blur on scroll)
Max-width: 1280px, centered
Padding: 0 24px

Left: 
  - Sparkles icon (lime #E3EF26, 24px)
  - "SmartSpend" text (cream white, 20px, font-bold, tracking-tight)
  
Center (hidden on mobile):
  - Nav links: "Features", "Pricing", "About"
  - Style: cream white, 14px, font-medium, opacity-80, hover:opacity-100
  
Right:
  - "Login" text button (cream white, 14px, font-medium)
  - "Get Started" button:
    - Background: #E3EF26
    - Text: #06231D, 14px, font-semibold
    - Padding: 10px 20px
    - Border-radius: 12px
    - Hover: #D4E020 with glow effect
```

**Hero Content (centered):**
```
Max-width: 800px
Text-align: center
Padding-top: 160px
Padding-bottom: 120px

Headline:
  - "Shaping Financial futures with expertise and care."
  - OR "Take Control of Your Finances with AI"
  - Font: 48px/3rem, 700 weight
  - Color: #F5F5F0 (cream)
  - Letter-spacing: -0.02em
  - Margin-bottom: 24px

Subheadline:
  - "We offer a comprehensive suite of services, from personal banking to business solutions, all delivered with unmatched precision and excellence."
  - Font: 18px, 400 weight
  - Color: rgba(245, 245, 240, 0.7)
  - Max-width: 600px
  - Margin-bottom: 40px

CTA Buttons (flex row, gap-16px, centered):
  Primary "Get Started":
    - Background: #E3EF26
    - Text: #06231D, 15px, font-semibold
    - Padding: 14px 28px
    - Border-radius: 12px
    - Box-shadow: var(--shadow-glow)
    
  Secondary "Watch Demo":
    - Background: transparent
    - Border: 1px solid rgba(245, 245, 240, 0.3)
    - Text: #F5F5F0, 15px, font-medium
    - Padding: 14px 28px
    - Border-radius: 12px
    - Includes Play icon (16px) before text
    - Hover: border-color rgba(245, 245, 240, 0.5)
```

**Hero Visual (below CTAs):**
```
Phone mockup cluster showing:
  - Central phone with app dashboard screenshot
  - Floating stat cards around it:
    - Balance card: "₹64,573.00" with +17% badge
    - Trading card: "BTC/USDT ₹41,984.00" with mini chart
    - Spending card: "Total Spendings ₹6,340.00" with line chart
    - User avatars row with transaction info
  
Cards styling:
  - Background: #0C342C
  - Border: 1px solid rgba(7, 102, 83, 0.5)
  - Border-radius: 16px
  - Box-shadow: var(--shadow-md)
  
Phone frame:
  - Dark bezel effect
  - Slight rotation (5deg) for depth
  - Glow behind: var(--shadow-glow-lg)
```

---

#### Section 2: Client Logos
**Background:** #06231D

```
Padding: 60px 0
Border-top: 1px solid rgba(7, 102, 83, 0.3)
Border-bottom: 1px solid rgba(7, 102, 83, 0.3)

Title:
  - "Our Recent Clients & Partners"
  - Font: 14px, 500 weight, uppercase, tracking-wide
  - Color: rgba(245, 245, 240, 0.5)
  - Margin-bottom: 32px

Logo Row:
  - 5 logos in flex row, justify-between
  - Logo opacity: 0.6
  - Hover opacity: 1
  - Filter: brightness(0) invert(1) (to make them white)
```

---

#### Section 3: Features Grid
**Background:** #0C342C with grain overlay

```
Padding: 100px 24px
Max-width: 1200px, centered

Section Header:
  - "Banking features designed to turn your product vision into reality."
  - Font: 36px, 700 weight
  - Color: #F5F5F0
  - Text-align: center
  - Max-width: 700px
  - Margin-bottom: 64px

Grid: 3 columns (1 on mobile), gap-24px

Feature Card:
  - Background: #06231D
  - Border: 1px solid rgba(7, 102, 83, 0.5)
  - Border-radius: 20px
  - Padding: 32px
  - Hover: border-color #076653, transform translateY(-4px)
  - Transition: all 0.3s ease

  Icon Container:
    - 48px × 48px
    - Background: rgba(227, 239, 38, 0.1)
    - Border-radius: 12px
    - Icon: lime #E3EF26, 24px
    
  Title:
    - Font: 20px, 600 weight
    - Color: #F5F5F0
    - Margin: 20px 0 12px
    
  Description:
    - Font: 15px, 400 weight
    - Color: rgba(245, 245, 240, 0.6)
    - Line-height: 1.6

Features:
  1. Icon: BarChart3 | "Visual Dashboard" | "See your income, expenses, and balance at a glance with beautiful, interactive charts"
  2. Icon: Sparkles | "AI Insights" | "Get personalized spending analysis and savings tips powered by Google Gemini AI"
  3. Icon: Shield | "Secure Payments" | "Upgrade to premium securely with Razorpay. One-time payment, lifetime access"
  4. Icon: Wallet | "Smart Tracking" | "Categorize and track every transaction automatically with intelligent categorization"
  5. Icon: TrendingUp | "Growth Analysis" | "Understand your financial growth with month-over-month comparisons"
  6. Icon: Bell | "Smart Alerts" | "Get notified about unusual spending patterns and budget limits"
```

---

#### Section 4: How It Works
**Background:** #06231D

```
Padding: 100px 24px
Max-width: 1000px, centered

Section Header:
  - "How SmartSpend Works"
  - Font: 36px, 700 weight
  - Color: #F5F5F0
  - Text-align: center
  - Margin-bottom: 64px

Steps Container:
  - Flex row (column on mobile)
  - Gap: 48px
  - Align: center
  
Step Card:
  - Flex: 1
  - Text-align: center
  
  Number Badge:
    - 48px × 48px circle
    - Background: #E3EF26
    - Color: #06231D
    - Font: 20px, 700 weight
    - Margin-bottom: 24px
    
  Title:
    - Font: 20px, 600 weight
    - Color: #F5F5F0
    - Margin-bottom: 12px
    
  Description:
    - Font: 15px, 400 weight
    - Color: rgba(245, 245, 240, 0.6)

Steps:
  1. "Sign Up Free" | "Create your account in seconds with just email and password"
  2. "Track Spending" | "Log income and expenses by category with our intuitive interface"
  3. "Get Insights" | "Unlock AI-powered financial advice tailored to your habits"

Connector Lines (desktop only):
  - Dashed line connecting step circles
  - Color: rgba(7, 102, 83, 0.5)
  - Height: 2px
```

---

#### Section 5: Premium CTA
**Background:** Gradient #076653 → #0C342C

```
Padding: 80px 24px
Text-align: center
Position: relative
Overflow: hidden

Glow Effect (background):
  - Radial gradient lime glow behind content
  - opacity: 0.1

Content:
  Sparkles Icon:
    - 40px, lime #E3EF26
    - Margin-bottom: 24px
    
  Headline:
    - "Unlock Premium for just ₹1"
    - Font: 40px, 700 weight
    - Color: #F5F5F0
    - Margin-bottom: 16px
    
  Subtext:
    - "One-time payment. Lifetime AI insights."
    - Font: 18px, 400 weight
    - Color: rgba(245, 245, 240, 0.7)
    - Margin-bottom: 32px
    
  CTA Button:
    - Background: #E3EF26
    - Text: #06231D, 16px, font-semibold
    - Padding: 16px 32px
    - Border-radius: 12px
    - Box-shadow: var(--shadow-glow)
    - Hover: scale(1.02), brighter glow
```

---

#### Section 6: Footer
**Background:** #06231D
**Border-top:** 1px solid rgba(7, 102, 83, 0.3)

```
Padding: 48px 24px
Max-width: 1200px, centered

Layout: Flex row, justify-between (stack on mobile)

Left:
  - Logo (Sparkles + "SmartSpend")
  - Copyright: "© 2026 SmartSpend. All rights reserved."
  - Color: rgba(245, 245, 240, 0.5)
  - Font: 14px

Right:
  - Links: "Features", "Pricing", "Login", "Register"
  - Color: rgba(245, 245, 240, 0.6)
  - Hover: #F5F5F0
  - Font: 14px
  - Gap: 32px
```

---

### PAGE 2: Login Page
**Route:** `/login`
**Access:** Public

**Layout:**
```
Full viewport, min-height: 100vh
Background: #06231D with grain overlay
Display: flex, align-center, justify-center
Padding: 24px
```

**Login Card:**
```
Background: #0C342C
Border: 1px solid rgba(7, 102, 83, 0.5)
Border-radius: 24px
Padding: 40px
Width: 100%
Max-width: 420px
Box-shadow: var(--shadow-lg)

Branding (centered):
  - Sparkles icon (lime, 28px) in lime/10 circle
  - "SmartSpend" text (cream, 24px, bold)
  - "Sign in to your account" (text-secondary, 14px)
  - Margin-bottom: 32px

Form Fields:
  Label:
    - Font: 14px, 500 weight
    - Color: rgba(245, 245, 240, 0.8)
    - Margin-bottom: 8px
    
  Input:
    - Background: #06231D
    - Border: 1px solid rgba(7, 102, 83, 0.5)
    - Border-radius: 12px
    - Padding: 14px 16px
    - Color: #F5F5F0
    - Font: 15px
    - Focus: border-color #E3EF26, box-shadow 0 0 0 3px rgba(227, 239, 38, 0.1)
    - Placeholder: rgba(245, 245, 240, 0.3)
    
  Field spacing: margin-bottom 20px

Submit Button:
  - Width: 100%
  - Background: #E3EF26
  - Color: #06231D
  - Font: 15px, 600 weight
  - Padding: 14px
  - Border-radius: 12px
  - Margin-top: 8px
  - Hover: #D4E020
  - Loading: spinner animation

Register Link:
  - "Don't have an account? Sign up"
  - Font: 14px
  - "Sign up" in lime #E3EF26
  - Margin-top: 24px
  - Text-align: center
```

---

### PAGE 3: Register Page
**Route:** `/register`

Identical to Login Page with:
- Title: "Create your free account"
- Additional fields: Full name, Confirm password
- Button text: "Create Account"
- Link: "Already have an account? Sign in"

---

### PAGE 4: Dashboard Page
**Route:** `/dashboard`
**Access:** Protected

**Layout:**
```
Background: #06231D
Min-height: 100vh

Uses shared Layout:
  - Navbar (top)
  - Sidebar (left, desktop only)
  - Content area (flex-1)
```

---

#### Navbar (Shared Component)
```
Height: 64px
Background: #0C342C
Border-bottom: 1px solid rgba(7, 102, 83, 0.3)
Position: sticky, top: 0, z-index: 40
Padding: 0 24px

Left:
  - Sparkles icon (lime, 22px)
  - "SmartSpend" (cream, 18px, bold)
  
Right (flex, gap-16px):
  - Premium badge (if premium):
    - Background: rgba(227, 239, 38, 0.15)
    - Border: 1px solid rgba(227, 239, 38, 0.3)
    - Color: #E3EF26
    - Font: 12px, 500 weight
    - Padding: 4px 10px
    - Border-radius: 20px
    - Crown icon (14px)
    
  - User name (hidden mobile):
    - Color: rgba(245, 245, 240, 0.7)
    - Font: 14px
    
  - Logout button:
    - 36px × 36px
    - Background: transparent
    - Hover: rgba(7, 102, 83, 0.3)
    - Border-radius: 8px
    - LogOut icon (18px, rgba(245, 245, 240, 0.6))
```

---

#### Sidebar (Shared Component)
```
Width: 240px
Background: #0C342C
Border-right: 1px solid rgba(7, 102, 83, 0.3)
Padding: 24px 16px
Display: none on mobile, flex on md+

Nav Items:
  - Flex column, gap-4px
  
  Item (default):
    - Padding: 12px 16px
    - Border-radius: 12px
    - Color: rgba(245, 245, 240, 0.6)
    - Font: 14px, 500 weight
    - Transition: all 0.2s
    - Hover: background rgba(7, 102, 83, 0.3), color #F5F5F0
    
  Item (active):
    - Background: rgba(227, 239, 38, 0.1)
    - Color: #E3EF26
    - Border: 1px solid rgba(227, 239, 38, 0.2)

Items:
  1. LayoutDashboard | "Dashboard" | /dashboard
  2. ArrowLeftRight | "Transactions" | /transactions
  3. Sparkles | "AI Insights" | /insights | PRO badge
  4. Zap | "Upgrade" | /upgrade | (hidden if premium)

PRO Badge:
  - Background: rgba(227, 239, 38, 0.15)
  - Color: #E3EF26
  - Font: 10px, 600 weight
  - Padding: 2px 6px
  - Border-radius: 4px
  - Margin-left: auto
```

---

#### Dashboard Content

**Section 1: Summary Cards**
```
Grid: 3 columns (1 mobile), gap-20px
Margin-bottom: 32px

Card Structure:
  - Background: #0C342C
  - Border: 1px solid rgba(7, 102, 83, 0.5)
  - Border-radius: 16px
  - Padding: 24px
  - Hover: border-color #076653

  Icon Container:
    - 44px × 44px
    - Border-radius: 12px
    - Display: flex, align-center, justify-center
    
  Label:
    - Font: 13px, 500 weight
    - Color: rgba(245, 245, 240, 0.5)
    - Margin-bottom: 4px
    
  Amount:
    - Font: 28px, 700 weight (monospace)
    - Letter-spacing: -0.02em

Cards:
  1. Total Income:
    - Icon bg: rgba(34, 197, 94, 0.15)
    - Icon: TrendingUp, #22C55E
    - Amount color: #22C55E
    
  2. Total Expenses:
    - Icon bg: rgba(239, 68, 68, 0.15)
    - Icon: TrendingDown, #EF4444
    - Amount color: #EF4444
    
  3. Net Balance:
    - Icon bg: rgba(227, 239, 38, 0.15)
    - Icon: Wallet, #E3EF26
    - Amount color: #E3EF26 (positive) or #F59E0B (negative)
```

---

**Section 2: Charts**
```
Grid: 2 columns (1 mobile), gap-20px
Margin-bottom: 32px

Chart Card:
  - Background: #0C342C
  - Border: 1px solid rgba(7, 102, 83, 0.5)
  - Border-radius: 16px
  - Padding: 24px
  
  Title:
    - Font: 16px, 600 weight
    - Color: #F5F5F0
    - Margin-bottom: 20px

Pie Chart (Spending by Category):
  - Donut style, inner radius 60%
  - Height: 240px
  - Colors per category (see Category Colors below)
  - Custom tooltip with dark theme
  - Legend below with colored dots
  
Bar Chart (Monthly Overview):
  - Grouped bars (Income green, Expense red)
  - Height: 240px
  - Grid lines: rgba(7, 102, 83, 0.3)
  - Axis text: rgba(245, 245, 240, 0.5)
```

---

**Section 3: Recent Transactions**
```
Card:
  - Background: #0C342C
  - Border: 1px solid rgba(7, 102, 83, 0.5)
  - Border-radius: 16px
  - Padding: 24px
  
Header:
  - Flex, justify-between
  - Title: "Recent Transactions" (16px, 600 weight, cream)
  - "View all" link (14px, #E3EF26, hover underline)
  
Transaction List:
  - Space-y: 12px
  - Max 5 items
  
Transaction Item:
  - Background: #06231D
  - Border: 1px solid rgba(7, 102, 83, 0.3)
  - Border-radius: 12px
  - Padding: 16px
  - Hover: border-color rgba(7, 102, 83, 0.5)
  
  Layout: flex, items-center, gap-12px
  
  Category Dot:
    - 10px × 10px circle
    - Color based on category
    
  Content (flex-1):
    - Description: 14px, 500 weight, #F5F5F0, truncate
    - Meta: 12px, rgba(245, 245, 240, 0.4), "Category · Date"
    
  Amount:
    - Font: 15px, 600 weight, monospace
    - Income: #22C55E with "+"
    - Expense: #EF4444 with "-"
    
  Actions (flex, gap-8px):
    - Edit: Pencil icon, 16px, rgba(245, 245, 240, 0.3), hover #E3EF26
    - Delete: Trash2 icon, 16px, rgba(245, 245, 240, 0.3), hover #EF4444
```

---

### PAGE 5: Transactions Page
**Route:** `/transactions`

**Header:**
```
Flex, justify-between, align-center
Margin-bottom: 24px

Left:
  - "Transactions" (24px, 700 weight, cream)
  - Count badge: "(24)" (14px, rgba(245, 245, 240, 0.4))
  
Right:
  - "Add" button:
    - Background: #E3EF26
    - Color: #06231D
    - Font: 14px, 600 weight
    - Padding: 10px 20px
    - Border-radius: 12px
    - Plus icon (16px)
```

**Filter Bar:**
```
Flex, wrap, gap-12px
Margin-bottom: 24px

Filter Input/Select:
  - Background: #0C342C
  - Border: 1px solid rgba(7, 102, 83, 0.5)
  - Border-radius: 10px
  - Padding: 10px 14px
  - Color: #F5F5F0
  - Font: 14px
  - Focus: border-color #E3EF26
  
Clear Button:
  - Color: rgba(245, 245, 240, 0.4)
  - Hover: #EF4444
  - X icon
```

**Transaction List:**
```
Space-y: 12px
Same Transaction Item styling as Dashboard
Full CRUD actions visible
```

---

### PAGE 6: AI Insights Page
**Route:** `/insights`

**Non-Premium State:**
```
Premium Banner:
  - Background: gradient #076653 → #0C342C
  - Border: 1px solid rgba(227, 239, 38, 0.2)
  - Border-radius: 20px
  - Padding: 48px
  - Text-align: center
  - Box-shadow: var(--shadow-glow)
  
  Sparkles icon in lime/20 circle (56px)
  Title: "Unlock AI Insights" (28px, bold, cream)
  Description: "Get personalized analysis..." (16px, rgba cream 0.7)
  CTA: "Upgrade for ₹1" (lime button with Zap icon)
```

**Premium State:**

**Header:**
```
Flex, justify-between, align-center
Margin-bottom: 32px

Left:
  - Sparkles icon (lime, 24px)
  - "AI Insights" (24px, 700 weight, cream)
  
Right:
  - Refresh button (outline, lime border, lime text, RefreshCw icon)
```

**Insight Cards:**
```
Space-y: 20px

Card Base:
  - Border-radius: 16px
  - Padding: 24px
  - Border: 1px solid (varies)

Overview Card:
  - Background: rgba(227, 239, 38, 0.05)
  - Border: rgba(227, 239, 38, 0.2)
  - Title icon: TrendingUp (lime)
  - Text: rgba(245, 245, 240, 0.8)

Top Spending Card:
  - Background: #0C342C
  - Border: rgba(7, 102, 83, 0.5)
  - List with category bars

Warnings Card:
  - Background: rgba(245, 158, 11, 0.05)
  - Border: rgba(245, 158, 11, 0.2)
  - Icon: AlertTriangle (amber)
  - Text: rgba(245, 158, 11, 0.9)

Savings Tips Card:
  - Background: rgba(34, 197, 94, 0.05)
  - Border: rgba(34, 197, 94, 0.2)
  - Icon: Lightbulb (green)
  - CheckCircle icons for each tip

Budget Advice Card:
  - Background: rgba(139, 92, 246, 0.05)
  - Border: rgba(139, 92, 246, 0.2)
  - Icon: PiggyBank (purple)
```

---

### PAGE 7: Upgrade Page
**Route:** `/upgrade`

**Already Premium:**
```
Centered card, text-center
Background: #0C342C
Border-radius: 20px
Padding: 48px

Green checkmark in green/20 circle
"You're Premium!" (24px, bold, #22C55E)
"Enjoy your AI-powered insights" (14px, rgba cream 0.6)
"View AI Insights" link (lime text)
```

**Non-Premium:**
```
Centered, max-width: 480px

Header:
  - Sparkles icon in lime/10 circle (64px)
  - "Unlock Premium" (32px, bold, cream)
  - Subtitle (16px, rgba cream 0.6)

Pricing Card:
  - Background: #0C342C
  - Border: 1px solid rgba(227, 239, 38, 0.2)
  - Border-radius: 20px
  - Padding: 32px
  - Box-shadow: var(--shadow-glow)
  
  Price:
    - "₹1" (48px, bold, #E3EF26)
    - "one-time payment" (14px, rgba cream 0.5)
    
  Feature List:
    - CheckCircle icons (#22C55E)
    - Feature text (14px, cream 0.8)
    - Space-y: 16px
    
  Pay Button:
    - Full width
    - Background: #E3EF26
    - Color: #06231D
    - Font: 16px, 600 weight
    - Padding: 16px
    - Border-radius: 12px
    - Zap icon
    
  Security Note:
    - "Secured by Razorpay · Test mode active"
    - Font: 12px
    - Color: rgba cream 0.4
    - Shield icon
```

---

## Category Colors

| Category | Color | Hex |
|----------|-------|-----|
| Food | Orange | #F97316 |
| Transport | Blue | #3B82F6 |
| Entertainment | Purple | #A855F7 |
| Shopping | Pink | #EC4899 |
| Bills | Yellow | #EAB308 |
| Health | Green | #22C55E |
| Salary | Teal | #14B8A6 |
| Other | Gray | #6B7280 |

---

## Animation & Transitions

```css
/* Default transition */
--transition-fast: 150ms ease;
--transition-base: 200ms ease;
--transition-slow: 300ms ease;

/* Hover lift effect */
.hover-lift:hover {
  transform: translateY(-2px);
}

/* Glow pulse (for premium elements) */
@keyframes glow-pulse {
  0%, 100% { box-shadow: 0 0 20px rgba(227, 239, 38, 0.1); }
  50% { box-shadow: 0 0 40px rgba(227, 239, 38, 0.2); }
}

/* Fade in */
@keyframes fade-in {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Spinner */
@keyframes spin {
  to { transform: rotate(360deg); }
}
```

---

## Responsive Breakpoints

| Breakpoint | Width | Changes |
|------------|-------|---------|
| Mobile | < 640px | Single column, no sidebar, stacked nav |
| Tablet | 640-1024px | 2-column grids, sidebar visible |
| Desktop | > 1024px | Full 3-column layouts, all features |

---

## Dark Mode Note

This design is **dark-mode by default**. The entire color system is built around the deep green palette. If a light mode is ever needed, consider:
- Swapping background to #F5F5F0
- Using #06231D for text
- Keeping lime #E3EF26 as accent
- Adjusting card backgrounds to white with green borders

---

## Implementation Notes for Claude Code

1. **CSS Variables:** Define all colors as CSS custom properties in globals.css
2. **Tailwind Config:** Extend theme with custom colors matching this palette
3. **Components:** Build reusable Card, Button, Input components with variants
4. **Grain Effect:** Add as a pseudo-element on body or main containers
5. **Charts:** Configure Recharts with dark theme, custom colors
6. **Animations:** Use Tailwind's animation utilities + custom keyframes
7. **Icons:** Use Lucide React consistently
8. **Fonts:** Import Inter and JetBrains Mono from Google Fonts

---

*This spec transforms SmartSpend from a standard indigo/white theme to a premium green fintech aesthetic inspired by modern banking interfaces.*
