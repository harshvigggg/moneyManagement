import { Header } from "@/components/landing/header"
import { Hero } from "@/components/landing/hero"
import { ClientLogos } from "@/components/landing/client-logos"
import { Features } from "@/components/landing/features"
import { Stats } from "@/components/landing/stats"
import { Testimonials } from "@/components/landing/testimonials"
import { CTA } from "@/components/landing/cta"
import { Footer } from "@/components/landing/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#06231D] text-white overflow-hidden">
      <Header />
      <Hero />
      <ClientLogos />
      <Features />
      <Stats />
      <Testimonials />
      <CTA />
      <Footer />
    </main>
  )
}
