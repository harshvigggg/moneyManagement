import { Shield, Zap, PieChart, CreditCard, Globe, Lock } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Bank-Grade Security",
    description: "Your data is protected with 256-bit encryption and multi-factor authentication.",
  },
  {
    icon: Zap,
    title: "Instant Transfers",
    description: "Send and receive money instantly, anywhere in the world, 24/7.",
  },
  {
    icon: PieChart,
    title: "Smart Analytics",
    description: "AI-powered insights help you understand your spending patterns.",
  },
  {
    icon: CreditCard,
    title: "Virtual Cards",
    description: "Create unlimited virtual cards for secure online purchases.",
  },
  {
    icon: Globe,
    title: "Global Access",
    description: "Access your accounts from anywhere with our mobile-first platform.",
  },
  {
    icon: Lock,
    title: "Privacy First",
    description: "We never sell your data. Your financial information stays yours.",
  },
]

export function Features() {
  return (
    <section className="py-20 lg:py-32" id="solutions">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance">
            Banking features designed to turn your{" "}
            <span className="text-[#E3EF26]">product vision</span> into reality.
          </h2>
          <p className="mt-6 text-gray-400 text-lg">
            Everything you need to manage your finances, all in one place.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative bg-[#0C342C]/50 border border-[#076653]/50 rounded-2xl p-6 lg:p-8 hover:border-[#E3EF26]/50 transition-all duration-300 hover:shadow-lg hover:shadow-[#E3EF26]/5"
            >
              {/* Icon */}
              <div className="w-12 h-12 bg-[#076653] rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#E3EF26] transition-colors">
                <feature.icon className="w-6 h-6 text-[#E3EF26] group-hover:text-[#06231D] transition-colors" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-semibold text-white mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Glow Effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#E3EF26]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
