"use client"

import { Button } from "@/components/ui/button"
import { Play, TrendingUp, ArrowUpRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
      {/* Background Gradient Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#E3EF26]/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#076653]/40 rounded-full blur-[100px]" />
        <div className="absolute top-1/2 right-1/3 w-64 h-64 bg-[#E3EF26]/10 rounded-full blur-[80px]" />
      </div>

      {/* Grain Texture Overlay */}
      <div 
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight text-balance">
            <span className="text-white">Shaping Financial </span>
            <span className="text-[#E3EF26]">futures</span>
            <span className="text-white"> with expertise and care.</span>
          </h1>

          {/* Subheadline */}
          <p className="mt-6 text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto text-pretty">
            We offer a comprehensive suite of services, from personal banking to business solutions, 
            all delivered with unmatched precision and excellence.
          </p>

          {/* CTA Buttons */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-[#E3EF26] text-[#06231D] hover:bg-[#d4e020] font-semibold px-8 py-6 text-lg"
            >
              Get Started
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-[#076653] text-white hover:bg-[#076653]/20 px-8 py-6 text-lg bg-transparent"
            >
              <Play className="w-5 h-5 mr-2 fill-current" />
              Watch Demo
            </Button>
          </div>
        </div>

        {/* Floating Cards */}
        <div className="relative mt-20 lg:mt-28">
          {/* Central Phone Mockup Area */}
          <div className="flex justify-center">
            <div className="relative w-72 h-[500px] bg-gradient-to-b from-[#0C342C] to-[#06231D] rounded-[3rem] border border-[#076653] shadow-2xl shadow-[#E3EF26]/10 overflow-hidden">
              {/* Phone Notch */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-[#06231D] rounded-b-2xl" />
              
              {/* Phone Content */}
              <div className="p-6 pt-10">
                <div className="text-center mb-6">
                  <p className="text-xs text-gray-400">Statistic</p>
                  <div className="flex justify-center gap-2 mt-2">
                    {["Week", "Month", "Year"].map((period, i) => (
                      <button
                        key={period}
                        className={`px-3 py-1 text-xs rounded-full transition-colors ${
                          i === 1 
                            ? "bg-[#E3EF26] text-[#06231D]" 
                            : "text-gray-400 hover:text-white"
                        }`}
                      >
                        {period}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Chart Placeholder */}
                <div className="h-32 flex items-end justify-center gap-1 mb-6">
                  {[40, 60, 45, 80, 55, 70, 90, 65, 85, 75].map((height, i) => (
                    <div
                      key={i}
                      className="w-4 rounded-t bg-gradient-to-t from-[#076653] to-[#E3EF26]"
                      style={{ height: `${height}%` }}
                    />
                  ))}
                </div>

                {/* Total Spending */}
                <div className="text-center">
                  <p className="text-xs text-gray-400">Total Spendings</p>
                  <p className="text-2xl font-bold text-white mt-1">$6,340.00</p>
                </div>

                {/* User Avatars */}
                <div className="flex justify-center -space-x-2 mt-6">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="w-8 h-8 rounded-full bg-gradient-to-br from-[#076653] to-[#E3EF26] border-2 border-[#06231D]"
                    />
                  ))}
                  <div className="w-8 h-8 rounded-full bg-[#0C342C] border-2 border-[#06231D] flex items-center justify-center">
                    <span className="text-xs text-gray-400">50+</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Left Floating Card - Crypto */}
          <div className="absolute left-4 lg:left-20 top-1/4 -translate-y-1/2">
            <div className="bg-[#0C342C]/90 backdrop-blur-sm border border-[#076653] rounded-2xl p-4 shadow-xl">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-[#F7931A] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">B</span>
                </div>
                <div>
                  <p className="text-xs text-gray-400">BTC/USDT</p>
                  <p className="text-lg font-bold text-white">$41,984.00</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#E3EF26]" />
                <span className="text-[#E3EF26] text-sm">+18.25%</span>
              </div>
              <Button size="sm" className="mt-3 w-full bg-[#E3EF26] text-[#06231D] hover:bg-[#d4e020]">
                Sell
              </Button>
            </div>
          </div>

          {/* Right Floating Card - Balance */}
          <div className="absolute right-4 lg:right-20 top-10">
            <div className="bg-[#0C342C]/90 backdrop-blur-sm border border-[#076653] rounded-2xl p-4 shadow-xl">
              <p className="text-xs text-gray-400 mb-1">Balance</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold text-white">64,573.00</p>
                <span className="px-2 py-0.5 bg-[#E3EF26]/20 text-[#E3EF26] text-xs rounded-full">+17%</span>
              </div>
            </div>
          </div>

          {/* Bottom Right Card - Growth */}
          <div className="absolute right-8 lg:right-32 bottom-10">
            <div className="bg-[#0C342C]/90 backdrop-blur-sm border border-[#076653] rounded-2xl p-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#076653] to-[#E3EF26]" />
                <div>
                  <p className="text-sm text-white">Devil Ron</p>
                  <p className="text-xs text-gray-400">02-13-2024</p>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex-1 h-8">
                  <svg viewBox="0 0 100 30" className="w-full h-full">
                    <path
                      d="M0,25 Q25,20 50,15 T100,5"
                      fill="none"
                      stroke="#E3EF26"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
                <span className="text-red-400 text-sm">-18,985.00</span>
              </div>
            </div>
          </div>

          {/* Top Left Card - Growth */}
          <div className="absolute left-8 lg:left-32 top-0 -translate-y-1/2">
            <div className="bg-[#0C342C]/90 backdrop-blur-sm border border-[#076653] rounded-2xl p-4 shadow-xl">
              <p className="text-xl font-bold text-white">+374.00</p>
              <div className="flex items-center gap-1 mt-1">
                <ArrowUpRight className="w-4 h-4 text-[#E3EF26]" />
                <span className="text-[#E3EF26] text-sm">+3.4%</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">Income this month</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
