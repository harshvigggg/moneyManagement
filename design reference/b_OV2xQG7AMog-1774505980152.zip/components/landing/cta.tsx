import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CTA() {
  return (
    <section className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background Gradient Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#E3EF26]/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-[#076653]/30 rounded-full blur-[100px]" />
      </div>

      {/* Grain Texture */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Content */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white text-balance">
          Ready to take control of your{" "}
          <span className="text-[#E3EF26]">financial future</span>?
        </h2>
        <p className="mt-6 text-gray-400 text-lg max-w-2xl mx-auto">
          Join over 500,000 businesses and individuals who trust SmartSpend 
          for their financial management needs.
        </p>

        {/* CTA Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button 
            size="lg" 
            className="bg-[#E3EF26] text-[#06231D] hover:bg-[#d4e020] font-semibold px-8 py-6 text-lg"
          >
            Start Free Trial
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="border-[#076653] text-white hover:bg-[#076653]/20 px-8 py-6 text-lg bg-transparent"
          >
            Talk to Sales
          </Button>
        </div>

        {/* Trust Badges */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-gray-400 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#E3EF26]/20 flex items-center justify-center">
              <span className="text-[#E3EF26] text-xs">&#10003;</span>
            </div>
            No credit card required
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#E3EF26]/20 flex items-center justify-center">
              <span className="text-[#E3EF26] text-xs">&#10003;</span>
            </div>
            14-day free trial
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#E3EF26]/20 flex items-center justify-center">
              <span className="text-[#E3EF26] text-xs">&#10003;</span>
            </div>
            Cancel anytime
          </div>
        </div>
      </div>
    </section>
  )
}
