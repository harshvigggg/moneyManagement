export function ClientLogos() {
  const logos = [
    { name: "Boltshift", icon: "B" },
    { name: "Lightbox", icon: "L" },
    { name: "FeatherDev", icon: "F" },
    { name: "GlobalBank", icon: "G" },
    { name: "Nietzsche", icon: "N" },
  ]

  return (
    <section className="py-16 border-y border-[#076653]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-gray-400 mb-10 text-sm">
          Our Recent Clients &amp; Partners
        </p>
        
        <div className="flex flex-wrap items-center justify-center gap-8 lg:gap-16">
          {logos.map((logo) => (
            <div
              key={logo.name}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-[#076653] flex items-center justify-center">
                <span className="text-[#E3EF26] font-bold">{logo.icon}</span>
              </div>
              <span className="font-medium">{logo.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
