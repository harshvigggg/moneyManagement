const stats = [
  { value: "$2.4B+", label: "Transactions processed" },
  { value: "500K+", label: "Active users" },
  { value: "99.9%", label: "Uptime guaranteed" },
  { value: "150+", label: "Countries supported" },
]

export function Stats() {
  return (
    <section className="py-20 lg:py-32 relative">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#06231D] via-[#0C342C]/50 to-[#06231D]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#E3EF26]">
                {stat.value}
              </p>
              <p className="mt-2 text-gray-400 text-sm sm:text-base">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
