import Link from "next/link"

const footerLinks = {
  product: {
    title: "Product",
    links: [
      { href: "#", label: "Features" },
      { href: "#", label: "Pricing" },
      { href: "#", label: "Security" },
      { href: "#", label: "Integrations" },
    ],
  },
  company: {
    title: "Company",
    links: [
      { href: "#", label: "About" },
      { href: "#", label: "Careers" },
      { href: "#", label: "Press" },
      { href: "#", label: "Contact" },
    ],
  },
  resources: {
    title: "Resources",
    links: [
      { href: "#", label: "Blog" },
      { href: "#", label: "Help Center" },
      { href: "#", label: "API Docs" },
      { href: "#", label: "Status" },
    ],
  },
  legal: {
    title: "Legal",
    links: [
      { href: "#", label: "Privacy" },
      { href: "#", label: "Terms" },
      { href: "#", label: "Cookies" },
      { href: "#", label: "Licenses" },
    ],
  },
}

export function Footer() {
  return (
    <footer className="border-t border-[#076653]/30 bg-[#06231D]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        {/* Top Section */}
        <div className="grid lg:grid-cols-6 gap-12 lg:gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#E3EF26] rounded-lg flex items-center justify-center">
                <span className="text-[#06231D] font-bold text-lg">S</span>
              </div>
              <span className="text-xl font-semibold text-white">SmartSpend</span>
            </Link>
            <p className="mt-4 text-gray-400 max-w-xs">
              Shaping financial futures with expertise and care. Your trusted partner in modern banking.
            </p>
          </div>

          {/* Links */}
          {Object.values(footerLinks).map((section) => (
            <div key={section.title}>
              <h3 className="text-white font-medium mb-4">{section.title}</h3>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-gray-400 hover:text-white transition-colors text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-[#076653]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} SmartSpend. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            {["Twitter", "LinkedIn", "GitHub"].map((social) => (
              <Link
                key={social}
                href="#"
                className="text-gray-400 hover:text-[#E3EF26] transition-colors text-sm"
              >
                {social}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
