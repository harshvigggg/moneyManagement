import { Star } from "lucide-react"

const testimonials = [
  {
    quote: "SmartSpend has completely transformed how I manage my business finances. The insights are invaluable.",
    author: "Sarah Chen",
    role: "CEO, TechFlow",
    rating: 5,
  },
  {
    quote: "The instant transfers and global access have made international business so much easier for our team.",
    author: "Marcus Johnson",
    role: "Finance Director, GlobalCorp",
    rating: 5,
  },
  {
    quote: "Finally, a banking app that understands modern businesses. The virtual cards feature is a game-changer.",
    author: "Elena Rodriguez",
    role: "Founder, StartupLab",
    rating: 5,
  },
]

export function Testimonials() {
  return (
    <section className="py-20 lg:py-32" id="insight">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white">
            Trusted by thousands of{" "}
            <span className="text-[#E3EF26]">businesses</span>
          </h2>
          <p className="mt-6 text-gray-400 text-lg">
            See what our customers have to say about their experience.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-[#0C342C]/50 border border-[#076653]/50 rounded-2xl p-6 lg:p-8"
            >
              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-[#E3EF26] text-[#E3EF26]"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-gray-300 leading-relaxed mb-6">
                &ldquo;{testimonial.quote}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#076653] to-[#E3EF26]" />
                <div>
                  <p className="text-white font-medium">{testimonial.author}</p>
                  <p className="text-gray-400 text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
